package com.freerdp.afreerdp.application;

public class GlobalApp extends com.freerdp.freerdpcore.application.GlobalApp
{
}
